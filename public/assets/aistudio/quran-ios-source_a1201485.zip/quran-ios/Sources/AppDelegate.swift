import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        window = UIWindow(frame: UIScreen.main.bounds)
        window?.rootViewController = MainTabBarController()
        window?.makeKeyAndVisible()
        return true
    }
    func applicationWillTerminate(_ application: UIApplication) { AudioPlayer.shared.stop() }
}

final class MainTabBarController: UITabBarController {
    override func viewDidLoad() {
        super.viewDidLoad()
        viewControllers = [
            navigation(ChapterListViewController(), title: "Surahs"),
            navigation(MushafViewController(), title: "Mushaf"),
            navigation(BookmarksViewController(), title: "Bookmarks"),
            navigation(SearchViewController(), title: "Search"),
            navigation(SettingsViewController(), title: "Settings")
        ]
        tabBar.tintColor = UIColor(red: 0.05, green: 0.43, blue: 0.36, alpha: 1)
    }
    private func navigation(_ root: UIViewController, title: String) -> UINavigationController {
        root.title = title
        let nav = UINavigationController(rootViewController: root)
        nav.tabBarItem = UITabBarItem(title: title, image: nil, selectedImage: nil)
        return nav
    }
}

extension UIViewController {
    func showNotice(_ message: String, title: String = "Quran Reader") {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
    func setBusy(_ busy: Bool) {
        if busy {
            let spinner = UIActivityIndicatorView(style: .gray)
            spinner.startAnimating()
            navigationItem.rightBarButtonItem = UIBarButtonItem(customView: spinner)
        }
    }
}
