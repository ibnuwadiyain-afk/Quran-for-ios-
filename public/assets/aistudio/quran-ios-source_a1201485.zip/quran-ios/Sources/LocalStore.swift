import Foundation

final class LocalStore {
    static let shared = LocalStore()
    private let defaults = UserDefaults.standard
    private let bookmarksKey = "savedQuranBookmarks"
    private let lastReadKey = "lastReadVerseKey"
    private let chaptersKey = "cachedChapterIndex"
    private init() {}

    func cacheChapters(_ chapters: [Chapter]) {
        if let data = try? JSONEncoder().encode(chapters) { defaults.set(data, forKey: chaptersKey) }
    }
    func cachedChapters() -> [Chapter]? {
        guard let data = defaults.data(forKey: chaptersKey) else { return nil }
        return try? JSONDecoder().decode([Chapter].self, from: data)
    }
    var lastReadVerseKey: String? {
        get { defaults.string(forKey: lastReadKey) }
        set { defaults.set(newValue, forKey: lastReadKey) }
    }
    func bookmarks() -> [Bookmark] {
        guard let data = defaults.data(forKey: bookmarksKey), let values = try? JSONDecoder().decode([Bookmark].self, from: data) else { return [] }
        return values.sorted { $0.createdAt > $1.createdAt }
    }
    func isBookmarked(_ key: String) -> Bool { bookmarks().contains { $0.verseKey == key } }
    func toggle(_ bookmark: Bookmark) -> Bool {
        var values = bookmarks()
        if let index = values.firstIndex(where: { $0.verseKey == bookmark.verseKey }) {
            values.remove(at: index); save(values); return false
        }
        values.append(bookmark); save(values); return true
    }
    func removeBookmark(_ key: String) { save(bookmarks().filter { $0.verseKey != key }) }
    private func save(_ values: [Bookmark]) {
        if let data = try? JSONEncoder().encode(values) { defaults.set(data, forKey: bookmarksKey) }
    }

    private var supportDirectory: URL {
        let url = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        try? FileManager.default.createDirectory(at: url, withIntermediateDirectories: true, attributes: nil)
        return url
    }
    private var readerCacheDirectory: URL {
        let url = supportDirectory.appendingPathComponent("QuranCache", isDirectory: true)
        try? FileManager.default.createDirectory(at: url, withIntermediateDirectories: true, attributes: nil)
        return url
    }
    private var offlineDirectory: URL {
        let url = supportDirectory.appendingPathComponent("OfflineQuran", isDirectory: true)
        try? FileManager.default.createDirectory(at: url, withIntermediateDirectories: true, attributes: nil)
        return url
    }
    private var pageImagesDirectory: URL {
        let url = offlineDirectory.appendingPathComponent("MushafPages", isDirectory: true)
        try? FileManager.default.createDirectory(at: url, withIntermediateDirectories: true, attributes: nil)
        return url
    }
    private var pageDataDirectory: URL {
        let url = offlineDirectory.appendingPathComponent("PageData", isDirectory: true)
        try? FileManager.default.createDirectory(at: url, withIntermediateDirectories: true, attributes: nil)
        return url
    }
    private func chapterCacheURL(_ chapterID: Int, words: Bool) -> URL {
        let suffix = words ? "-words" : ""
        return readerCacheDirectory.appendingPathComponent("chapter-\(chapterID)-translation-\(AppSettings.translationID)\(suffix).json")
    }
    func cache(verses: [Verse], chapterID: Int, includeWords: Bool = false) {
        if let data = try? JSONEncoder().encode(verses) { try? data.write(to: chapterCacheURL(chapterID, words: includeWords), options: .atomic) }
    }
    func cachedVerses(chapterID: Int, includeWords: Bool = false) -> [Verse]? {
        let url = chapterCacheURL(chapterID, words: includeWords)
        guard let data = try? Data(contentsOf: url) else { return nil }
        return try? JSONDecoder().decode([Verse].self, from: data)
    }
    private func pageDataURL(_ page: Int, translationID: Int) -> URL {
        pageDataDirectory.appendingPathComponent(String(format: "page-%03d-translation-%d.json", page, translationID))
    }
    func offlinePageData(_ page: Int, translationID: Int) -> Data? {
        try? Data(contentsOf: pageDataURL(page, translationID: translationID))
    }
    func saveOfflinePageData(_ data: Data, page: Int, translationID: Int) throws {
        try data.write(to: pageDataURL(page, translationID: translationID), options: .atomic)
    }
    func saveOfflinePageImage(_ data: Data, page: Int) throws {
        try data.write(to: pageImagesDirectory.appendingPathComponent(String(format: "page%03d.png", page)), options: .atomic)
    }
    func pageImageURL(_ page: Int) -> URL? {
        let url = pageImagesDirectory.appendingPathComponent(String(format: "page%03d.png", page))
        return FileManager.default.fileExists(atPath: url.path) ? url : nil
    }
    func pageDataExists(_ page: Int, translationID: Int) -> Bool {
        FileManager.default.fileExists(atPath: pageDataURL(page, translationID: translationID).path)
    }
    func pageImageExists(_ page: Int) -> Bool { pageImageURL(page) != nil }
    func cacheOfflineChapter(_ verses: [Verse], chapterID: Int, translationID: Int) {
        let suffix = "chapter-\(chapterID)-translation-\(translationID)-words.json"
        let url = readerCacheDirectory.appendingPathComponent(suffix)
        if let data = try? JSONEncoder().encode(verses) { try? data.write(to: url, options: .atomic) }
    }
    func clearReaderCache() { try? FileManager.default.removeItem(at: readerCacheDirectory) }
    func clearOfflineQuran() { try? FileManager.default.removeItem(at: offlineDirectory) }
}
