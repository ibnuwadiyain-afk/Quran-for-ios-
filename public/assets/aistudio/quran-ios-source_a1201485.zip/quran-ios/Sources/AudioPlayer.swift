import Foundation
import AVFoundation

final class AudioPlayer {
    static let shared = AudioPlayer()
    private var player: AVPlayer?
    private var downloadTask: URLSessionDownloadTask?
    private init() {
        try? AVAudioSession.sharedInstance().setCategory(.playback, mode: .spokenAudio, options: [])
        try? AVAudioSession.sharedInstance().setActive(true)
    }

    func play(_ url: URL) {
        player?.pause()
        player = AVPlayer(url: url)
        player?.play()
    }

    func toggle() {
        guard let player = player else { return }
        if player.timeControlStatus == .playing { player.pause() } else { player.play() }
    }

    func stop() { player?.pause(); player = nil }

    func download(_ url: URL, chapterID: Int, completion: @escaping (Result<URL, Error>) -> Void) {
        downloadTask?.cancel()
        downloadTask = URLSession.shared.downloadTask(with: url) { temp, _, error in
            if let error = error { DispatchQueue.main.async { completion(.failure(error)) }; return }
            guard let temp = temp else { DispatchQueue.main.async { completion(.failure(APIError.server)) }; return }
            let folder = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent("Recitations", isDirectory: true)
            try? FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true, attributes: nil)
            let destination = folder.appendingPathComponent("chapter-\(chapterID)-reciter-\(AppSettings.reciterID).mp3")
            try? FileManager.default.removeItem(at: destination)
            do {
                try FileManager.default.moveItem(at: temp, to: destination)
                DispatchQueue.main.async { completion(.success(destination)) }
            } catch { DispatchQueue.main.async { completion(.failure(error)) } }
        }
        downloadTask?.resume()
    }

    func downloadedURL(chapterID: Int) -> URL? {
        let url = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent("Recitations/chapter-\(chapterID)-reciter-\(AppSettings.reciterID).mp3")
        return FileManager.default.fileExists(atPath: url.path) ? url : nil
    }
}
