#!/bin/bash
set -euo pipefail
APP="${1:-build/Build/Products/Release-iphoneos/Quran Reader.app}"
OUT="${2:-QuranReader-unsigned.ipa}"
if [[ ! -d "$APP" ]]; then
  echo "App bundle not found: $APP" >&2
  exit 1
fi
rm -rf Payload "$OUT"
mkdir Payload
cp -R "$APP" Payload/
/usr/bin/zip -qry "$OUT" Payload
rm -rf Payload
echo "Created $OUT (unsigned; sign before installing on a device)."
